
//====================================================================
//
//  AppDelegate.h
//  DemoSkeleton
//
//  Created by Jason Riggs on 11/30/11.
//  Copyright (c) 2011 Stanford University. All rights reserved.
//
//====================================================================

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
