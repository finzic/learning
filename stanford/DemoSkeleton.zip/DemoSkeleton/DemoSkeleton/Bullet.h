
//====================================================================
//
//  Bullet.h
//  GameDemo
//
//  Created by Jason Riggs on 11/29/11.
//  Copyright (c) 2011 Stanford University. All rights reserved.
//
//====================================================================

#ifndef GameDemo_Bullet_h
#define GameDemo_Bullet_h

#include "Entity.h"





#endif
