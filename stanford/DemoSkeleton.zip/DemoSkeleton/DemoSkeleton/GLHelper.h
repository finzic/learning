
//====================================================================
//
//  GLHelper.h
//  GameDemo
//
//  Created by Jason Riggs on 11/29/11.
//  Copyright (c) 2011 Stanford University. All rights reserved.
//
//====================================================================

#ifndef GameDemo_GLHelper_h
#define GameDemo_GLHelper_h



#endif
